let ponto1 = document.getElementById('selectMenu1')
let ponto2 = document.getElementById('selectMenu2')
let ponto3 = document.getElementById('selectMenu3')
let elementoInputPontos = document.getElementById('disabledInput')

let pontosTotal

function Enviar(){

    pontosTotal = 0

    if(ponto1.value == '2' || ponto2.value == '2' || ponto3.value == '2'){

        alert('Alguma resposta não foi selecionada!')

    }else{

        if(ponto1.value == '1'){

            pontosTotal++

        }

        if(ponto2.value == '1'){

            pontosTotal++

        }

        if(ponto3.value == '1'){

            pontosTotal++

        }

        elementoInputPontos.value = pontosTotal
        
        if(pontosTotal == 3){
    
            alert('Quiz finalizado! Parabéns, você fez a pontuação máxima :D')            
    
        }else{
    
            alert('Quiz finalizado! Confira sua pontuação :)')  
    
        }
        

    }

}